# Logo CHRTV PL▷Y — bản PNG

Sinh ra từ chính asset của web, không vẽ lại:
- `chrtv-logo-mark.svg` = SVG của `LogoMark()` trong `src/components/Logo.jsx` (bản có viền sáng + gloss mà header đang dùng)
- `chrtv-favicon-tile-*.png` = từ `public/logo.svg` (bản đang gắn `<link rel="icon">`)

Render bằng sharp/librsvg ở `density: 384` → nét vector, nền trong suốt (PNG-32).

## File

| File | Size | Dùng cho |
|---|---|---|
| `chrtv-logo-1024.png` | 1024×1024 | dùng chung, upload store, ảnh chia sẻ |
| `chrtv-logo-512.png` | 512 | PWA `icon-512` |
| `chrtv-logo-192.png` | 192 | PWA `icon-192` |
| `chrtv-logo-180.png` | 180 | `apple-touch-icon` (web đang trỏ .svg vào thẻ này — iPhone bỏ qua SVG, nên trỏ sang file này) |
| `chrtv-logo-128 / 64 / 48 / 32 / 16` | | favicon các cỡ |
| `chrtv-favicon-16 / 32 / 48.png` | full-bleed | favicon sát mép, rõ hơn ở cỡ nhỏ (đã cắt khoảng đệm 2/64 của tile) |
| `chrtv-favicon-tile-*.png` | | bản `public/logo.svg` gốc (không có lớp gloss) |
| `chrtv-logo-lockup.png` | 1200×320, `@2x` = 2400×640 | nền trong suốt — chữ TRẮNG, chỉ dùng trên nền tối |
| `chrtv-logo-lockup-dark.png` | 1200×320 + `@2x` | trên nền `#0d0e12` (màu app) |
| `chrtv-logo-lockup-light.png` | 1200×320 + `@2x` | trên nền trắng (tài liệu, hợp đồng, báo giá QC) |

## ⚠️ Phần chữ trong lockup chưa phải font chuẩn

App dùng **Inter** (`font-black`, tailwind `fontFamily.sans`) cho chữ “CHRTV”,
nhưng sandbox không tải được Inter (CDN bị chặn) nên phần chữ đang render bằng
**DejaVu Sans Bold** — hình dạng chữ hơi khác web một chút.

Cách chốt bản chuẩn: lấy `Inter-Black.ttf` (hoặc thư mục font trong
`node_modules/@fontsource/inter`) bỏ vào `~/.fonts`, chạy `fc-cache -f`, rồi chạy lại
`node render-lockup.mjs` và đổi `font-family="DejaVu Sans"` → `font-family="Inter"`
trong `chrtv-logo-lockup.svg`. Phần icon/mark thì đã chuẩn 100% vì là vector gốc.

## Render lại / thêm cỡ

```bash
cd /home/user/logo-export
node render-lockup.mjs          # 3 lockup + @2x
node favicon.mjs                # favicon full-bleed 16/32/48
```

Mark ở bất kỳ cỡ nào: `sharp chrtv-logo-mark.svg -resize 1024:1024 out.png` (hoặc sửa
mảng `sizes` trong `favicon.mjs`).
