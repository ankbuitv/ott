import sharp from '/home/user/ott/node_modules/sharp/dist/index.mjs';
import { readFileSync } from 'node:fs';
const svg = readFileSync('/home/user/logo-export/chrtv-logo-mark.svg','utf8');
// favicon nên full-bleed: cắt bỏ viền trong suốt 2/64 rồi phóng kín khung
for (const px of [16,32,48]) {
  await sharp(Buffer.from(svg),{density:768}).trim({threshold:1}).resize(px,px,{fit:'cover'}).png({compressionLevel:9})
    .toFile(`/home/user/logo-export/chrtv-favicon-${px}.png`);
  console.log('✓ chrtv-favicon-'+px+'.png (full-bleed)');
}
