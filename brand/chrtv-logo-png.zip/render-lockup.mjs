import sharp from '/home/user/ott/node_modules/sharp/dist/index.mjs';
import { readFileSync } from 'node:fs';
const OUT='/home/user/logo-export';
const base=readFileSync(`${OUT}/chrtv-logo-lockup.svg`,'utf8');
const variants={'chrtv-logo-lockup.png':{t:'#ffffff',s:'#78716c',bg:null},'chrtv-logo-lockup-dark.png':{t:'#ffffff',s:'#a8a29e',bg:'#0d0e12'},'chrtv-logo-lockup-light.png':{t:'#0d0e12',s:'#57534e',bg:'#ffffff'}};
for(const [name,v] of Object.entries(variants)){
  let svg=base.replace('fill="#ffffff" letter-spacing="-2"',`fill="${v.t}" letter-spacing="-2"`).replace('fill="#78716c"',`fill="${v.s}"`);
  if(v.bg) svg=svg.replace('<rect x="0" y="0" width="1200" height="320" rx="0" fill="none"/>',`<rect x="0" y="0" width="1200" height="320" fill="${v.bg}"/>`);
  await sharp(Buffer.from(svg),{density:384}).resize(1200,320).png({compressionLevel:9}).toFile(`${OUT}/${name}`);
  await sharp(Buffer.from(svg),{density:384}).resize(2400,640).png({compressionLevel:9}).toFile(`${OUT}/${name.replace('.png','@2x.png')}`);
  console.log('✓',name);
}
